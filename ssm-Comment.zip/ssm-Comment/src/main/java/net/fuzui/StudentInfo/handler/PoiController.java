package net.fuzui.StudentInfo.handler;


import java.io.InputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.fuzui.StudentInfo.pojo.*;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import net.fuzui.StudentInfo.service.PoiService;
import net.fuzui.StudentInfo.mapper.CommentMapper;


/**
 * 导入导出controller
 *
 */
@Controller
public class PoiController {

    private static final Logger log=LoggerFactory.getLogger(PoiController.class);

    private static final String prefix="poi";

    @Autowired
    private CommentMapper CommentMapper;

    @Autowired
    private PoiService poiService;

    @Value("${poi.excel.sheet.name.xls}")
    private String sheetCommentName;

    @Value("poiExcel.xls")
    private String excelCommentName;

    /**
     * 获取产品列表-可用于搜索
     * @param name
     * @return
     */
    @RequestMapping(value=prefix+"/list",method=RequestMethod.GET)
    @ResponseBody
    public BaseResponse<List<Comment>> list(String name){
        BaseResponse<List<Comment>> response=new BaseResponse<List<Comment>>(StatusCode.Success);
        try {
            List<Comment> Comments=CommentMapper.selectAll(name);
            response.setData(Comments);
        } catch (Exception e) {
            log.error("获取产品列表发生异常: ",e.fillInStackTrace());
        }

        return response;
    }

    /**
     * 下载excel
     * @param response
     * @return
     */
    @RequestMapping(value=prefix+"/excel/export",method=RequestMethod.GET)
    public @ResponseBody String exportExcel(HttpServletResponse response,String search){
        try {
            List<Comment> Comments=CommentMapper.selectAll(search);
            String[] headers=new String[]{"教师编号","评价","学生编号","评价编号","频率","日期","班级编号","课程编号","分析结果"};
            List<Map<Integer, Object>> dataList=ExcelBeanUtil.manageCommentList(Comments);
            log.info("excel下载填充数据： {} ",dataList);

            Workbook wb=new HSSFWorkbook();
            ExcelUtil.fillExcelSheetData(dataList, wb, headers, sheetCommentName);
            WebUtil.downloadExcel(response, wb, excelCommentName);
            return excelCommentName;
        } catch (Exception e) {
            log.error("下载excel 发生异常：",e.fillInStackTrace());
        }
        return null;
    }

    /**
     * 上传excel导入数据
     * @param request
     * @return
     * 1、不要忘了支持springmvc上传文件的配置
     */
    @SuppressWarnings("rawtypes")
    @RequestMapping(value=prefix+"/excel/upload",method=RequestMethod.POST,consumes=MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseBody
    public BaseResponse uploadExcel(MultipartHttpServletRequest request){
        BaseResponse response=new BaseResponse<>(StatusCode.Success);
        try {
            MultipartFile file=request.getFile("commentFile");
            if (file==null || file.getName()==null) {
                return new BaseResponse<>(StatusCode.Invalid_Param);
            }
            String fileName=file.getOriginalFilename();
            String suffix=StringUtils.substring(fileName, fileName.lastIndexOf(".")+1);

            log.info("文件名：{} 文件后缀名：{} ",fileName,suffix);

            Workbook wb=poiService.getWorkbook(file,suffix);
            List<Comment> products=poiService.readExcelData(wb);

            //批量插入-第一种方法
            //productService.insertBatch(products);

            //批量插入-第二种方法(注意jdbc链接mysql允许批量插入删除的配置)
            CommentMapper.insertBatch(products);
            System.out.println("processing excel upload!");
        } catch (Exception e) {
            log.error("上传excel导入数据 发生异常：",e.fillInStackTrace());
            return new BaseResponse<>(StatusCode.System_Error);

        }
        return response;
    }
    @RequestMapping(value = "/InputExcel.do")
    @ResponseBody
    public String InputExcel(@RequestParam("file") MultipartFile file, HttpServletRequest request) throws Exception {
        String flag = "02";// 上传标志
        if (!file.isEmpty()) {
            try {
                String originalFilename = file.getOriginalFilename();// 原文件名字
                log.info("文件名：" + originalFilename);
                InputStream is = file.getInputStream();// 获取输入流
                flag = poiService.InputExcel(is, originalFilename);
            } catch (Exception e) {
                flag = "03";// 上传出错
                e.printStackTrace();
            }
        }
        return flag;
    }
}


