package net.fuzui.StudentInfo.service;

import net.fuzui.StudentInfo.pojo.Feedback;

import java.util.List;

/**
 * @ProjectName: StudentInfo
 * @Package: net.fuzui.StudentInfo.service
 * @ClassName: FeedbackService
 * @Description: 反馈service接口层
 */

public interface FeedbackService {

    /**
     *  添加反馈
     * @param Feedback   反馈信息
     * @return  插入结果 !=0则插入成功
     */
    public int insertFeedback(Feedback Feedback);

    /**
     *  根据反馈编号删除反馈信息信息
     * @param cid   反馈编号
     * @return  删除结果，!=0则删除成功
     */
    public int deleteFeedback(String cid);


    /**
     *  根据反馈编号查询出反馈实体
     * @param cid
     * @return
     */
    public Feedback getByFeedbackId(String cid);


    /**
     * 查询全部反馈，接住sql语句进行分页
     * @param pageNo
     * @param pageSize
     * @return      查询结果
     */
    public List<Feedback> selectFeedbackBySql(int pageNo, int pageSize);
    /**
     * 根据反馈编号查询反馈信息
     * @param pageNo
     * @param pageSize
     * @return  查询结果
     */
    public List<Feedback> getByFeedbackFid(int pageNo, int pageSize,String cid);
    /**
     *  根据教师编号查询反馈信息
     * @param pageNo
     * @param pageSize
     * @param i_id    教师编号
     * @return 结果
     */
    public List<Feedback> getByFeedbackTeacher(int pageNo, int pageSize,String i_id);
    /**
     *  根据班级查询反馈信息
     * @param pageNo
     * @param pageSize
     * @param classid      班级编号
     * @return  结果
     */
    public List<Feedback> getByFeedbackClass(int pageNo, int pageSize,String classid);

    /**
     * 根据课程编号查询反馈信息
     * @param pageNo
     * @param pageSize
     * @param course_id     课程编号
     * @return  查询结果
     */
    public List<Feedback> getByFeedbackCourse(int pageNo, int pageSize,String course_id);


    /**
     *  ajax验证反馈编号是否存在
     * @param cid   反馈编号
     * @return  结果
     */
    public String ajaxQueryByCid(String cid);

}
