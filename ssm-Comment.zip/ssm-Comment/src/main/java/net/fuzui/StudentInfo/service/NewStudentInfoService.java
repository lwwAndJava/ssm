package net.fuzui.StudentInfo.service;

import net.fuzui.StudentInfo.pojo.NewStudent;

import java.util.List;


public interface NewStudentInfoService {
    List<NewStudent> getAllStudent();
}
