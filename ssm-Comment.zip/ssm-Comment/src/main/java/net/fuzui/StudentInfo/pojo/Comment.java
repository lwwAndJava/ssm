package net.fuzui.StudentInfo.pojo;

/**
 * @ProjectName: StudentInfo
 * @Package: net.fuzui.StudentInfo.pojo
 * @ClassName: Comment
 * @Description: 评价实体类
 */
public class Comment {

    //教师编号
    private String i_id;
    //评价号
    private int c_id;
    //学生编号
    private String s_id;
    //评价
    private String comment;
    //频率
    private String frequency;
    //日期
    private String cDate;
    private String classId;
    private String courseId;
    private String analysisResult;
    private String name;
    private int value;
    /**
     * 默认构造方法
     */
    public Comment() {

    }
    /**
     *  置取方法
     */
    public String getCommentIid(){return i_id; }
    public void setCommentIid(String i_id) {
        this.i_id = i_id;
    }
    public int getCid() {
        return c_id;
    }
    public void setCid(int cid) {
        this.c_id = cid;
    }
    public String getCommentSid(){return s_id; }
    public void setCommentSid(String s_id) {
        this.s_id = s_id;
    }
    public String getComment() {
        return comment;
    }
    public void setComment(String comment) {
        this.comment = comment;
    }
    public String getFrequency() {
        return frequency;
    }
    public void setFrequency(String frequency) {
        this.frequency= frequency;
    }
    public String getcDate() {
        return cDate;
    }
    public void setcDate(String date) {
        this.cDate = date;
    }

    public String toString(){
        return "Comment [Teacher id= "+i_id+" , comment= "+comment+" , student id= "+s_id+" , comment id= "+c_id+
                " , frequency= "+frequency+" , date= "+cDate+" ]";
    }
    public String getClassId(){return classId; }
    public void setClassId(String classId) {
        this.classId = classId;
    }
    public String getCourseId(){return courseId; }
    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }
    public String getAnalysisResult(){return analysisResult; }
    public void setAnalysisResult(String analysisResult) {
        this.analysisResult = analysisResult;
    }
    public String getName(){return name; }
    public int getValue(){
        return value;
    }
}
