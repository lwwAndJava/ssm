package net.fuzui.StudentInfo.pojo;

/**
 * @ProjectName: StudentInfo
 * @Package: net.fuzui.StudentInfo.pojo
 * @ClassName: SC
 */
public class SC implements java.io.Serializable {
    /**
     *  序列化
     */
    private static final long serialVersionUID = 1L;

    private String class_id;

    /**
     * 默认构造方法
     */
    public SC() {

    }

    /**
     *  置取方法
     */

    public String getCid() {
        return class_id;
    }

    public void setCid(String cid) {
        this.class_id = cid;
    }


}


