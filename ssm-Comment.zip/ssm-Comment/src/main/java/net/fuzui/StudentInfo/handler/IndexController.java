package net.fuzui.StudentInfo.handler;
import net.fuzui.StudentInfo.pojo.analysis;
import net.fuzui.StudentInfo.service.IndexService;
import net.fuzui.StudentInfo.service.analysisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class IndexController {

    @Autowired
    public IndexService indexServlet;

    @RequestMapping("/getPieCharts")
    public String toBar(HttpServletRequest request, Model model) {
        return "PieCharts";
    }


    @RequestMapping("/queryForList")
    @ResponseBody
    public List<Map<String, Object>> queryForList() {
        List<Map<String, Object>> lists = indexServlet.queryForList();
        for (Map<String, Object> map : lists) {
            for (String s : map.keySet()) {
                System.out.print("value: " + map.get(s) +" ");
            }
        }
        return lists;
    }
}


