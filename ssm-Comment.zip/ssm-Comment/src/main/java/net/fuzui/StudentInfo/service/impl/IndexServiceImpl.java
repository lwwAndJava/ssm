package net.fuzui.StudentInfo.service.impl;

import net.fuzui.StudentInfo.mapper.IndexDao;
import net.fuzui.StudentInfo.service.IndexService;
import net.fuzui.StudentInfo.service.analysisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Service
public class IndexServiceImpl implements IndexService {
    @Autowired
    IndexDao indexDao;
    @Override
    public List<Map<String, Object>> queryForList() {
        return indexDao.queryForList();
    }
}
