package net.fuzui.StudentInfo.service;

import java.io.InputStream;
import java.util.*;

import net.fuzui.StudentInfo.mapper.CommentMapper;
import net.fuzui.StudentInfo.tool.Excel;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.ImportResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import net.fuzui.StudentInfo.pojo.WorkBookVersion;
import net.fuzui.StudentInfo.pojo.Comment;
import net.fuzui.StudentInfo.pojo.DateUtil;
import net.fuzui.StudentInfo.pojo.ExcelUtil;

@Service
public class PoiService {

    private static final Logger log=LoggerFactory.getLogger(PoiService.class);

    private CommentMapper commentMapper;
    /**
     * 读取excel数据
     * @param wb
     * @return
     * @throws Exception
     */
    public List<Comment> readExcelData(Workbook wb) throws Exception{
        Comment Comment=null;

        List<Comment> Comments=new ArrayList<Comment>();
        Row row=null;
        int numSheet=wb.getNumberOfSheets();
        if (numSheet>0) {
            for(int i=0;i<numSheet;i++){
                Sheet sheet=wb.getSheetAt(i);
                int numRow=sheet.getLastRowNum();
                if (numRow>0) {
                    for(int j=1;j<=numRow;j++){
                        //TODO：跳过excel sheet表格头部
                        row=sheet.getRow(j);
                        Comment=new Comment();

                        String i_id=ExcelUtil.manageCell(row.getCell(1), null);
                        String comment=ExcelUtil.manageCell(row.getCell(2), null);
                        String s_id=ExcelUtil.manageCell(row.getCell(3), null);
                        int c_id=Integer.parseInt(ExcelUtil.manageCell(row.getCell(4), null));
                        String frequency=ExcelUtil.manageCell(row.getCell(5), null);
                        String date=ExcelUtil.manageCell(row.getCell(6), "yyyy-MM-dd");
                        String classId=ExcelUtil.manageCell(row.getCell(7), null);
                        String courseId=ExcelUtil.manageCell(row.getCell(8), null);
                        String analysisResult=ExcelUtil.manageCell(row.getCell(9), null);

                        Comment.setCommentIid(i_id);
                        Comment.setComment(comment);
                        Comment.setCommentSid(s_id);
                        Comment.setCid(c_id);
                        Comment.setFrequency(frequency);
                        Comment.setcDate(date);
                        Comment.setClassId(classId);
                        Comment.setCourseId(courseId);
                        Comment.setAnalysisResult(analysisResult);

                        Comments.add(Comment);
                    }
                }
            }
        }

        log.info("获取数据列表: {} ",Comments);
        return Comments;
    }

    /**
     * 根据版本来区分获取workbook实例
     * @param version
     * @return
     */
    public Workbook getWorkbook(String version,InputStream inputStream) throws Exception{
        Workbook wk=null;
        if (Objects.equals(WorkBookVersion.WorkBook2003.getCode(), version)) {
            wk=new HSSFWorkbook(inputStream);
        }else if (Objects.equals(WorkBookVersion.WorkBook2007.getCode(), version)) {
            wk=new XSSFWorkbook(inputStream);
        }

        return wk;
    }

    /**
     * 根据file区分获取workbook实例
     * @return
     */
    public Workbook getWorkbook(MultipartFile file,String suffix) throws Exception{
        Workbook wk=null;
        if (Objects.equals(WorkBookVersion.WorkBook2003Xls.getCode(), suffix)) {
            wk=new HSSFWorkbook(file.getInputStream());
        }else if (Objects.equals(WorkBookVersion.WorkBook2007Xlsx.getCode(), suffix)) {
            wk=new XSSFWorkbook(file.getInputStream());
        }

        return wk;
    }

    public String InputExcel(InputStream is, String originalFilename) {
        Map<String,Object> ginsengMap = new HashMap<String,Object>();
        List<ArrayList<Object>> list;
        if (originalFilename.endsWith(".xls")) {
            list = Excel.readExcel2003(is);
        } else {
            list = Excel.readExcel2007(is);
        }
        for (List<Object> row : list) {
            ginsengMap.put("i_id", row.get(0).toString());
            ginsengMap.put("comment", row.get(1).toString());
            ginsengMap.put("s_id", row.get(2).toString());
            ginsengMap.put("c_id", row.get(3).toString());
            ginsengMap.put("frequency", row.get(4).toString());
            ginsengMap.put("date", row.get(5).toString());
            ginsengMap.put("class_class_id", row.get(6).toString());
            ginsengMap.put("courseId", row.get(7).toString());
            ginsengMap.put("analysisResult", row.get(8).toString());
            commentMapper.insertComment(ginsengMap);
        }

        return "01";
    }

}


