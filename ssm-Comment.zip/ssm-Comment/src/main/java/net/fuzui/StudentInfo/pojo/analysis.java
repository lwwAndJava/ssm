package net.fuzui.StudentInfo.pojo;

import java.util.List;
import java.util.Map;

public class analysis{
    private int value;
    private String name;
    public analysis(){}
    public int getValue(){
        return value;
    }
    public int setValue(int v){
        return this.value=v;
    }
    public String getName(){
        return name;
    }
    public String setName(String v){
        return this.name=v;
    }
}


