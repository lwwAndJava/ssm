package net.fuzui.StudentInfo.pojo;

/**
 * @ProjectName: StudentInfo
 * @Package: net.fuzui.StudentInfo.pojo
 * @ClassName: Teacher
 * @Description: 教师实体类
 */
public class Teacher implements java.io.Serializable{
    //序列化
    private static final long serialVersionUID = 1L;
    //教师编号
    private String tid;
    //教师姓名
    private String i_name;
    //教师密码
    private String i_password;
    //教师邮箱
    private String i_email;
    //教师简介
    //private String introduction;

    /**
     * 默认构造方法
     */
    public Teacher() {

    }

    /**
     *  置取方法
     */
    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String getTname() {
        return i_name;
    }

    public void setTname(String i_name) {
        this.i_name = i_name;
    }

    public String getTpassword() {
        return i_password;
    }

    public void setTpassword(String i_password) {
        this.i_password = i_password;
    }

    public String getTemail() {
        return i_email;
    }

    public void setTemail(String i_email) {
        this.i_email = i_email;
    }


}
