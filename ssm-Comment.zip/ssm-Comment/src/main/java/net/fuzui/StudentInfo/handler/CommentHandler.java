package net.fuzui.StudentInfo.handler;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import net.fuzui.StudentInfo.pojo.*;
import net.fuzui.StudentInfo.service.CommentService;
import net.fuzui.StudentInfo.service.NewStudentInfoService;
import net.fuzui.StudentInfo.service.PoiService;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @ProjectName: StudentInfo
 * @Package: net.fuzui.StudentInfo.handler
 * @ClassName: CommentHandler
 * @Description: 评价handler类（servlet）
 */

@Controller
@RequestMapping("/CommentHandler")
@SessionAttributes("commentList")
public class CommentHandler {
    @Autowired
    CommentService commentService;
    private static final Logger log = LoggerFactory.getLogger(CommentHandler.class);

    private static final String prefix = "Comment";

    @Value("${poi.excel.sheet.name}")
    private String sheetCommentName;

    @Value("${poi.excel.file.name}")
    private String excelCommentName;

    @Autowired
    private net.fuzui.StudentInfo.mapper.CommentMapper CommentMapper;

    @Autowired
    private PoiService poiService;

    public void pageIn(Model model, List list) {
        PageInfo page = new PageInfo(list, 5);
        model.addAttribute("pageInfo", page);
    }

    public void queryCou(HttpServletRequest request) {
        List<Comment> commentList = new ArrayList<Comment>();
        commentList = commentService.selectCommentBySql(1, 10);
        request.setAttribute("commentList", commentList);
    }

    // 查询
    @RequestMapping(value = "/query/{pn}", method = RequestMethod.GET)
    public String redirect(@RequestParam("serc") String serc, @RequestParam("condition") String condition,
                           HttpServletRequest request, @PathVariable(value = "pn") String pn, Model model) {
        int no = Integer.parseInt(pn);
        List<Comment> commentList = new ArrayList<Comment>();
        PageHelper.startPage(no, 5);
        request.setAttribute("serc", serc);
        request.setAttribute("condition", condition);
        if (serc.equals("all")) { //查询全部
            commentList = commentService.selectCommentBySql(1, 10);
            pageIn(model, commentList);
            request.setAttribute("commentList", commentList);
            System.out.println(commentList);
            return "admin/queryComment";
        } else if (serc.equals("sid")) { //根据评价编号查询评价
            commentList = commentService.getByCommentCid(1, 10, Integer.parseInt(condition));
            pageIn(model, commentList);
            request.setAttribute("commentList", commentList);
            System.out.println("sid");
            return "admin/queryComment";
        } else if (serc.equals("nam")) {//根据课程编号查询评价
            commentList = commentService.getByCommentCourse(1, 10, condition);
            pageIn(model, commentList);
            request.setAttribute("commentList", commentList);
            System.out.println(commentList);
            System.out.println("cla");
            return "admin/queryComment";
        } else if (serc.equals("col")) { //根据教师编号查询评价
            commentList = commentService.getByCommentTeacher(1, 10, condition);
            pageIn(model, commentList);
            request.setAttribute("commentList", commentList);
            System.out.println(commentList);
            System.out.println("col");
            return "admin/queryComment";
        } else if (serc.equals("type")) {//根据班级编号查询评价
            commentList = commentService.getByCommentClass(1, 10, condition);
            pageIn(model, commentList);
            request.setAttribute("commentList", commentList);
            System.out.println(commentList);
            System.out.println("pro");
            return "admin/queryComment";
        } else {  //展示全部信息
            commentList = commentService.selectCommentBySql(1, 10);
            pageIn(model, commentList);
            request.setAttribute("commentList", commentList);
            return "admin/queryComment";
        }
    }

    //删除反馈
    @RequestMapping(value = "/delete/{cid}", method = RequestMethod.GET)
    public String deleteStudent(@PathVariable(value = "cid") String cid, HttpServletRequest request) {


        if (commentService.deleteComment(cid) != 0) {
            System.out.println("success");
            queryCou(request);
            return "success";
        } else {
            System.out.println("fail");
            return "fail";
        }

    }

    //跳转到queryComment页面
    @RequestMapping(value = "/finalPage", method = RequestMethod.GET)
    public String finalPage(HttpSession httpSession, HttpServletRequest request) {
        Object admin = request.getSession().getAttribute("commentList");
        System.out.println(admin + "111111111111111111111111111111111111111111111111111111111111111111111111111");
        return "admin/queryComment";
    }


    //跳转到queryComment页面
    @RequestMapping("/managecou/{pn}")
    public String manageComment(HttpServletRequest request, @PathVariable(value = "pn") String pn, Model model) {
        int no = Integer.parseInt(pn);
        List<Comment> commentList = new ArrayList<Comment>();
        PageHelper.startPage(no, 5);
        commentList = commentService.selectCommentBySql(1, 10);
        pageIn(model, commentList);
        request.setAttribute("commentList", commentList);
        return "admin/queryComment";
    }

    /**
     * 获取产品列表
     *
     * @param name
     * @return
     */
    @RequestMapping(value = prefix + "/list", method = RequestMethod.GET)
    @ResponseBody
    public List<Comment> list(String name) {
        List<Comment> Comments = new ArrayList<Comment>();
        try {
            Comments = CommentMapper.selectAll(name);
        } catch (Exception e) {
            log.error("获取产品列表发生异常: ", e.fillInStackTrace());
        }

        return Comments;
    }

    /**
     * 导出excel
     *
     * @param response
     * @return
     */
    @RequestMapping(value = prefix + "/excel/export", method = RequestMethod.GET)
    public @ResponseBody
    String exportExcel(HttpServletResponse response, String search) {
        try {
            List<Comment> Comments = CommentMapper.selectAll(search);
            String[] headers = new String[]{"教师id", "评价", "学生id", "评价id", "频率", "采购日期", "备注信息"};
            List<Map<Integer, Object>> dataList = ExcelBeanUtil.manageCommentList(Comments);
            log.info("excel下载填充数据： {} ", dataList);

            Workbook wb = new HSSFWorkbook();
            ExcelUtil.fillExcelSheetData(dataList, wb, headers, sheetCommentName);
            WebUtil.downloadExcel(response, wb, excelCommentName);
            return excelCommentName;
        } catch (Exception e) {
            log.error("下载excel 发生异常：", e.fillInStackTrace());
        }
        return null;
    }

    /**
     * 上传excel导入数据
     *
     * @param request
     * @return
     */
    @SuppressWarnings("rawtypes")
    @RequestMapping(value = prefix + "/excel/upload", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseBody
    public BaseResponse uploadExcel(MultipartHttpServletRequest request) {
        BaseResponse response = new BaseResponse<>(StatusCode.Success);
        try {
            MultipartFile file = request.getFile("CommentFile");
            if (file == null || file.getName() == null) {
                return new BaseResponse<>(StatusCode.Invalid_Param);
            }
            String fileName = file.getOriginalFilename();
            String suffix = StringUtils.substring(fileName, fileName.lastIndexOf(".") + 1);
            log.info("文件名：{} 文件后缀名：{} ", fileName, suffix);

            Workbook wb = poiService.getWorkbook(file, suffix);
            List<Comment> Comments = poiService.readExcelData(wb);

            //批量插入-第一种方法
            //CommentService.insertBatch(Comments);

            //批量插入-第二种方法(注意jdbc链接mysql允许批量插入删除的配置)
            CommentMapper.insertBatch(Comments);
        } catch (Exception e) {
            log.error("上传excel导入数据 发生异常：", e.fillInStackTrace());
            return new BaseResponse<>(StatusCode.System_Error);
        }
        return response;
    }

    @Autowired
    private NewStudentInfoService newStudentInfoService;


    @RequestMapping(value = "/getScore")
    @ResponseBody
    public List<Double> getScore() {
        List<NewStudent> newStudents = newStudentInfoService.getAllStudent();
        List<Double> scores = null;
        for (NewStudent newStudent : newStudents) {
            assert scores != null;
            scores.add(newStudent.getScore());
        }
        assert scores != null;
        System.out.println("饼图请求数据:" + scores.toString());
        return scores;
    }


    @RequestMapping(value = "/getPieCharts")
    public String getPieCharts() {
        return "PieCharts";
    }

    @RequestMapping(value = "/pie", method = RequestMethod.POST)
    @ResponseBody
    public List<sorceResult> getData() {
        List<NewStudent> students = newStudentInfoService.getAllStudent();
        List<sorceResult> results = new ArrayList<sorceResult>();
        for (NewStudent newStudent : students) {
            // 把学生的成绩和姓名封装到一个result
            sorceResult result = new sorceResult(newStudent.getScore(), newStudent.getName());
            results.add(result);
        }
        System.out.println("json数据:" + results);
        return results;
    }

}
