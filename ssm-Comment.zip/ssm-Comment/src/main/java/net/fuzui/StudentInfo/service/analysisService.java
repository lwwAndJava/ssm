package net.fuzui.StudentInfo.service;

import net.fuzui.StudentInfo.pojo.analysis;

import java.util.List;
import java.util.Map;

/**
 * @ProjectName: StudentInfo
 * @Package: net.fuzui.StudentInfo.service
 * @ClassName: analysisService
 * @Description: 评价service接口层
 */

public interface analysisService {

    /**
     * 查询全部评价结果排序
     * @return      查询结果
     */
    public List<analysis> queryForList();
}
