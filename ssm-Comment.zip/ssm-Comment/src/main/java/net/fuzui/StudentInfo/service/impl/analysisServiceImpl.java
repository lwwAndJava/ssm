package net.fuzui.StudentInfo.service.impl;
import net.fuzui.StudentInfo.mapper.analysisMapper;
import net.fuzui.StudentInfo.pojo.analysis;
import net.fuzui.StudentInfo.service.analysisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Service
public class analysisServiceImpl  implements analysisService {
    @Autowired
    private analysisMapper analysisMapper;
    @Override
    public List<analysis> queryForList() {
        Map<String,Object> data = new HashMap<String,Object>();
        return analysisMapper.queryForList(data);
    }
}
