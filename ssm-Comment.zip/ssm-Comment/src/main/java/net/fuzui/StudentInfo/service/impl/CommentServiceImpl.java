package net.fuzui.StudentInfo.service.impl;

import net.fuzui.StudentInfo.mapper.CommentMapper;
import net.fuzui.StudentInfo.pojo.Comment;
import net.fuzui.StudentInfo.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @ProjectName: StudentInfo
 * @Package: net.fuzui.StudentInfo.service.impl
 * @ClassName: CommentServiceImpl
 * @Description: 评价service具体实现类
 */
@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentMapper commentMapper;


    /**
     *  根据评价编号删除评价信息信息
     * @param cid   评价编号
     * @return  删除结果，!=0则删除成功
     */
    @Override
    public int deleteComment(String cid) {
        return commentMapper.deleteComment(cid);
    }



    /**
     * 查询全部评价，接住sql语句进行分页
     * @param pageNo
     * @param pageSize
     * @return      查询结果
     */
    @Override
    public List<Comment> selectCommentBySql(int pageNo, int pageSize) {
        Map<String,Object> data = new HashMap<String,Object>();
        data.put("pageNo",(pageNo-1) * pageSize);
        data.put("pageSize",pageSize);
        return commentMapper.selectCommentBySql(data);
    }

    /**
     * 根据评价编号查询评价信息
     * @param pageNo
     * @param pageSize
     * @return  查询结果
     */
    @Override
    public List<Comment> getByCommentCid(int pageNo, int pageSize, int c_id) {
        Map<String,Object> data = new HashMap<String,Object>();
        data.put("pageNo",(pageNo-1) * pageSize);
        data.put("pageSize",pageSize);
        data.put("c_id",c_id);
        return commentMapper.getByCommentCid(data);
    }
    /**
     * 根据课程编号查询评价信息
     * @param pageNo
     * @param pageSize
     * @param courseId
     * @return  查询结果
     */
    @Override
    public List<Comment> getByCommentCourse(int pageNo, int pageSize, String courseId) {
        Map<String,Object> data = new HashMap<String,Object>();
        data.put("pageNo",(pageNo-1) * pageSize);
        data.put("pageSize",pageSize);
        data.put("courseId",courseId);
        return commentMapper.getByCommentCourse(data);
    }

    /**
     *  根据教师编号查询评价信息
     * @param pageNo
     * @param pageSize
     * @param i_id    所属学院
     * @return 结果
     */
    @Override
    public List<Comment> getByCommentTeacher(int pageNo, int pageSize, String i_id) {
        Map<String,Object> data = new HashMap<String,Object>();
        data.put("pageNo",(pageNo-1) * pageSize);
        data.put("pageSize",pageSize);
        data.put("i_id",i_id);
        return commentMapper.getByCommentTeacher(data);
    }

    /**
     *  根据班级类询评价信息
     * @param pageNo
     * @param pageSize
     * @param class_id      评价类型
     * @return  结果
     */
    @Override
    public List<Comment> getByCommentClass(int pageNo, int pageSize, String class_id) {
        Map<String,Object> data = new HashMap<String,Object>();
        data.put("pageNo",(pageNo-1) * pageSize);
        data.put("pageSize",pageSize);
        data.put("classId",class_id);
        return commentMapper.getByCommentClass(data);
    }

    /**
     *  ajax验证评价编号是否存在
     * @param cid   评价编号
     * @return  结果
     */
    @Override
    public String ajaxQueryByCid(String cid) {
        return commentMapper.ajaxQueryByCid(cid);
    }

    public List<Comment> findOrder(){
        return commentMapper.findOrder();
    }

}
