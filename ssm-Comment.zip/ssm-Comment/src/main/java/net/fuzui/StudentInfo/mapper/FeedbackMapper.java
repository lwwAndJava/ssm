package net.fuzui.StudentInfo.mapper;

import net.fuzui.StudentInfo.pojo.Feedback;

import java.util.List;
import java.util.Map;

/**
 * @ProjectName: StudentInfo
 * @Package: net.fuzui.StudentInfo.mapper
 * @ClassName: FeedbackMapper
 * @Description: 反馈数据访问层接口类
 */
public interface FeedbackMapper {

    /**
     *  添加反馈
     * @param Feedback   反馈信息
     * @return  插入结果 !=0则插入成功
     */
    public int insertFeedback(Feedback Feedback);

    /**
     *  根据反馈编号删除反馈信息信息
     * @param fid   反馈编号
     * @return  删除结果，!=0则删除成功
     */
    public int deleteFeedback(String fid);


    /**
     *  根据反馈编号查询出反馈实体
     * @param cid
     * @return
     */
    public Feedback getByFeedbackId(String cid);


    /**
     * 查询全部反馈，接住sql语句进行分页
     * @param data
     * @return      查询结果
     */
    public List<Feedback> selectFeedbackBySql(Map<String, Object> data);

    /**
     * 根据反馈编号查询反馈信息
     * @param data
     * @return  查询结果
     */
    public List<Feedback> getByFeedbackFid(Map<String, Object> data);

    /**
     * 根据课程编号查询反馈信息
     * @param data
     * @return  查询结果
     */
    public List<Feedback> getByFeedbackCourse(Map<String, Object> data);

    /**
     *  根据教师编号查询反馈信息
     * @param data
     * @return 结果
     */
    public List<Feedback> getByFeedbackTeacher(Map<String, Object> data);

    /**
     *  根据班级查询反馈信息
     * @param data
     * @return  结果
     */
    public List<Feedback> getByFeedbackClass(Map<String, Object> data);

    /**
     *  ajax验证反馈编号是否存在
     * @param cid   反馈编号
     * @return  结果
     */
    public String ajaxQueryByCid(String cid);
}
