package net.fuzui.StudentInfo.kumo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KumoApplication {

    public static void main(String[] args) {
        SpringApplication.run(KumoApplication.class, args);
    }

}
