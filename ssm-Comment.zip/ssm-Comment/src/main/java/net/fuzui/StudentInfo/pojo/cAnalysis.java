package net.fuzui.StudentInfo.pojo;

import java.util.List;

public class cAnalysis implements java.io.Serializable {
    /**
     *  序列化
     */
    private static final long serialVersionUID = 1L;
    private int caid;
    private String cresult;
    private int commentId;
    private String i_id;

    //评价
    private String comment;
    //日期
    private String cDate;
    private String classId;
    private String courseId;


    /**
     *  置取方法
     */
    public String getCommentIid(){return i_id; }
    public void setCommentIid(String i_id) {
        this.i_id = i_id;
    }


    public String getComment() {
        return comment;
    }
    public void setComment(String comment) {
        this.comment = comment;
    }
    public String getcDate() {
        return cDate;
    }
    public void setcDate(String date) {
        this.cDate = date;
    }

    public String getClassId(){return classId; }
    public void setClassId(String classId) {
        this.classId = classId;
    }
    public String getCourseId(){return courseId; }
    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }
    public cAnalysis(){}

    public int getCaid(){
        return caid;
    }
    public int setCaid(int v){
        return this.caid=v;
    }
    public String getCresult(){
        return cresult;
    }
    public String setCresult(String v){
        return this.cresult=v;
    }
    public int getCommentId(){
        return commentId;
    }
    public int setCommentId(int v){
        return this.commentId=v;
    }

}
