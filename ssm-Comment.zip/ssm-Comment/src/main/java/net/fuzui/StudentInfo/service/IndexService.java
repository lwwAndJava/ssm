package net.fuzui.StudentInfo.service;

import net.fuzui.StudentInfo.mapper.IndexDao;

import java.util.List;
import java.util.Map;

public interface IndexService {
    public List<Map<String, Object>> queryForList();
}
