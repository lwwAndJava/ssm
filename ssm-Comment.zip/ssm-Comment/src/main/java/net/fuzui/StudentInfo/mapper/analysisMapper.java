package net.fuzui.StudentInfo.mapper;

import net.fuzui.StudentInfo.pojo.analysis;

import java.util.List;
import java.util.Map;


/**
 * @ProjectName: StudentInfo
 * @Package: net.fuzui.StudentInfo.mapper
 * @ClassName: alysisMapper
 * @Description: 评价分析结果访问层接口类
 */
public interface analysisMapper {

    /**
     * 评价分析排序
     * @return      查询结果
     */
    public List<analysis> queryForList(Map<String, Object> data);

}
