package net.fuzui.StudentInfo.service.impl;

import net.fuzui.StudentInfo.mapper.FeedbackMapper;
import net.fuzui.StudentInfo.pojo.Feedback;
import net.fuzui.StudentInfo.service.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @ProjectName: StudentInfo
 * @Package: net.fuzui.StudentInfo.service.impl
 * @ClassName: FeedbackServiceImpl
 * @Description: 反馈service具体实现类
 */
@Service
public class FeedbackServiceImpl implements FeedbackService {

    @Autowired
    private FeedbackMapper FeedbackMapper;

    /**
     *  添加反馈
     * @param Feedback   反馈信息
     * @return  插入结果 !=0则插入成功
     */
    @Override
    public int insertFeedback(Feedback Feedback) {
        return FeedbackMapper.insertFeedback(Feedback);
    }

    /**
     *  根据反馈编号删除反馈信息信息
     * @param cid   反馈编号
     * @return  删除结果，!=0则删除成功
     */
    @Override
    public int deleteFeedback(String cid) {
        return FeedbackMapper.deleteFeedback(cid);
    }

    /**
     *  根据反馈编号查询出反馈实体
     * @param cid
     * @return
     */
    @Override
    public Feedback  getByFeedbackId(String cid) {
        return FeedbackMapper. getByFeedbackId(cid);
    }

    /**
     * 查询全部反馈，接住sql语句进行分页
     * @param pageNo
     * @param pageSize
     * @return      查询结果
     */
    @Override
    public List<Feedback> selectFeedbackBySql(int pageNo, int pageSize) {
        Map<String,Object> data = new HashMap<String,Object>();
        data.put("pageNo",(pageNo-1) * pageSize);
        data.put("pageSize",pageSize);
        return FeedbackMapper.selectFeedbackBySql(data);
    }

    /**
     * 根据反馈编号查询反馈信息
     * @param pageNo
     * @param pageSize
     * @return  查询结果
     */
    @Override
    public List<Feedback> getByFeedbackFid(int pageNo, int pageSize, String f_id) {
        Map<String,Object> data = new HashMap<String,Object>();
        data.put("pageNo",(pageNo-1) * pageSize);
        data.put("pageSize",pageSize);
        data.put("f_id",f_id);
        return FeedbackMapper.getByFeedbackFid(data);
    }

    /**
     *  根据教师编号查询反馈信息
     * @param pageNo
     * @param pageSize
     * @param i_id    所属学院
     * @return 结果
     */
    @Override
    public List<Feedback> getByFeedbackTeacher(int pageNo, int pageSize, String i_id) {
        Map<String,Object> data = new HashMap<String,Object>();
        data.put("pageNo",(pageNo-1) * pageSize);
        data.put("pageSize",pageSize);
        data.put("i_id",i_id);
        return FeedbackMapper.getByFeedbackTeacher(data);
    }

    /**
     *  根据班级类询反馈信息
     * @param pageNo
     * @param pageSize
     * @param class_id      反馈类型
     * @return  结果
     */
    @Override
    public List<Feedback> getByFeedbackClass(int pageNo, int pageSize, String class_id) {
        Map<String,Object> data = new HashMap<String,Object>();
        data.put("pageNo",(pageNo-1) * pageSize);
        data.put("pageSize",pageSize);
        data.put("class_id",class_id);
        return FeedbackMapper.getByFeedbackClass(data);
    }
    /**
     * 根据反馈名称查询反馈信息
     * @param pageNo
     * @param pageSize
     * @param course_id
     * @return  查询结果
     */
    @Override
    public List<Feedback> getByFeedbackCourse(int pageNo, int pageSize, String course_id) {
        Map<String,Object> data = new HashMap<String,Object>();
        data.put("pageNo",(pageNo-1) * pageSize);
        data.put("pageSize",pageSize);
        data.put("course_id",course_id);
        return FeedbackMapper.getByFeedbackCourse(data);
    }
    /**
     *  ajax验证反馈编号是否存在
     * @param cid   反馈编号
     * @return  结果
     */
    @Override
    public String ajaxQueryByCid(String cid) {
        return FeedbackMapper.ajaxQueryByCid(cid);
    }
}

