package net.fuzui.StudentInfo.pojo;

/**
 * @ProjectName: StudentInfo
 * @Package: net.fuzui.StudentInfo.pojo
 * @ClassName: Feedback
 * @Description: 反馈实体类
 */
public class Feedback implements java.io.Serializable{
    /**
     *  序列化
     */
    private static final long serialVersionUID = 1L;
    //反馈编号
    private String f_id;
    //反馈
    private String feedback;
    //教师编号
    private String i_id;
    //班级号
    private String class_id;
    //日期
    private String fDate;
    //学生编号
    private String s_id;

    /**
     * 默认构造方法
     */
    public Feedback() {

    }

    /**
     *  置取方法
     */
    public String getFeedbackIid(){return i_id; }
    public void setFeedbackIid(String i_id) {
        this.i_id = i_id;
    }
    public String getFid() {
        return f_id;
    }
    public void setFid(String fid) {
        this.f_id = fid;
    }
    public String getFeedbackSid(){return s_id; }
    public void setFeedbackSid(String s_id) {
        this.s_id = s_id;
    }
    public String getFeedback() {
        return feedback;
    }
    public void setFeedback(String feedback) {
        this.feedback= feedback;
    }
    public String getClass_id() {
        return class_id;
    }
    public void setClass_id(String class_id) {
        this.class_id= class_id;
    }
    public String getfDate() {
        return fDate;
    }
    public void setfDate(String date) {
        this.fDate = date;
    }
}