package net.fuzui.StudentInfo.handler;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import net.fuzui.StudentInfo.pojo.Feedback;
import net.fuzui.StudentInfo.service.FeedbackService;

/**
 *
 * @ProjectName: StudentInfo
 * @Package: net.fuzui.StudentInfo.handler
 * @ClassName: FeedbackHandler
 * @Description: 评价handler类（servlet）
 */

@Controller
@RequestMapping("/FeedbackHandler")
@SessionAttributes("FeedbackList")
public class FeedbackHandler {
    @Autowired
    FeedbackService FeedbackService;

    // 添加
    @RequestMapping("/addFeedback")
    public String addFeedback(Feedback Feedback, Model model) {


        if (FeedbackService.insertFeedback(Feedback) != 0) {
            model.addAttribute("Feedback", Feedback);
            return "success";
        } else {
            return "fail";
        }
    }

    public void pageIn(Model model,List list) {
        PageInfo page = new PageInfo(list, 5);
        model.addAttribute("pageInfo", page);
    }

    public void queryCou(HttpServletRequest request) {
        List<Feedback> FeedbackList = new ArrayList<Feedback>();
        FeedbackList = FeedbackService.selectFeedbackBySql(1,10);
        request.setAttribute("FeedbackList", FeedbackList);
    }

    // 查询
    @RequestMapping(value = "/query/{pn}", method = RequestMethod.GET)
    public String redirect(@RequestParam("serc") String serc, @RequestParam("condition") String condition,
                           HttpServletRequest request,@PathVariable(value = "pn") String pn,Model model) {
        int no = Integer.parseInt(pn);
        List<Feedback> FeedbackList = new ArrayList<Feedback>();
        PageHelper.startPage(no, 5);
        request.setAttribute("serc", serc);
        request.setAttribute("condition", condition);
        if (serc.equals("all")) { //查询全部
            FeedbackList = FeedbackService.selectFeedbackBySql(1,10);
            pageIn(model, FeedbackList);
            request.setAttribute("FeedbackList", FeedbackList);
            System.out.println(FeedbackList);
            return "admin/queryFeedback";
        } else if (serc.equals("sid")) {  //根据反馈编号查询
            FeedbackList = FeedbackService.getByFeedbackFid(1,10,condition);
            pageIn(model, FeedbackList);
            request.setAttribute("FeedbackList", FeedbackList);
            System.out.println("sid");
            return "admin/queryFeedback";
        } else if (serc.equals("nam")) {
            FeedbackList = FeedbackService.getByFeedbackCourse(1,10,condition);
            pageIn(model, FeedbackList);
            request.setAttribute("FeedbackList", FeedbackList);
            System.out.println(FeedbackList);
            System.out.println("cla");
            return "admin/queryFeedback";
        } else if (serc.equals("col")) { //根据教师编号查询
            FeedbackList = FeedbackService.getByFeedbackTeacher(1,10,condition);
            pageIn(model, FeedbackList);
            request.setAttribute("FeedbackList", FeedbackList);
            System.out.println(FeedbackList);
            System.out.println("col");
            return "admin/queryFeedback";
        } else if (serc.equals("type")) { //根据班级编号查询
            FeedbackList = FeedbackService.getByFeedbackClass(1,10,condition);
            pageIn(model, FeedbackList);
            request.setAttribute("FeedbackList", FeedbackList);
            System.out.println(FeedbackList);
            System.out.println("pro");
            return "admin/queryFeedback";
        } else { //查询全部
            FeedbackList = FeedbackService.selectFeedbackBySql(1,10);
            pageIn(model, FeedbackList);
            request.setAttribute("FeedbackList", FeedbackList);
            return "admin/queryFeedback";
        }
    }

    //删除学生
    @RequestMapping(value = "/delete/{cid}", method = RequestMethod.GET)
    public String deleteStudent(@PathVariable(value = "cid") String cid, HttpServletRequest request) {
        if (FeedbackService.deleteFeedback(cid) != 0) {
            System.out.println("success");
            queryCou(request);
            return "success";
        } else {
            System.out.println("fail");
            return "fail";
        }
    }

    //跳转到queryFeedback页面
    @RequestMapping(value = "/finalPage", method = RequestMethod.GET)
    public String finalPage(HttpSession httpSession,HttpServletRequest request) {
        Object admin = request.getSession().getAttribute("FeedbackList");
        System.out.println(admin+"111111111111111111111111111111111111111111111111111111111111111111111111111");
        return "admin/queryFeedback";
    }



    //跳转到queryFeedback页面
    @RequestMapping("/manageFeedback/{pn}")
    public String manageFeedback(HttpServletRequest request,@PathVariable(value = "pn") String pn,Model model) {
        int no = Integer.parseInt(pn);
        List<Feedback> FeedbackList = new ArrayList<Feedback>();
        PageHelper.startPage(no, 5);
        FeedbackList = FeedbackService.selectFeedbackBySql(1,10);
        pageIn(model, FeedbackList);
        request.setAttribute("FeedbackList", FeedbackList);
        return "admin/queryFeedback";
    }
}
