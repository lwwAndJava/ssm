package net.fuzui.StudentInfo.service;

import net.fuzui.StudentInfo.pojo.Comment;
import net.fuzui.StudentInfo.pojo.analysis;
import org.springframework.ui.ModelMap;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * @ProjectName: StudentInfo
 * @Package: net.fuzui.StudentInfo.service
 * @ClassName: CommentService
 * @Description: 评价service接口层
 */

public interface CommentService {


    /**
     *  根据评价编号删除评价信息信息
     * @param cid   评价编号
     * @return  删除结果，!=0则删除成功
     */
    public int deleteComment(String cid);



    /**
     * 查询全部评价，接住sql语句进行分页
     * @param pageNo
     * @param pageSize
     * @return      查询结果
     */
    public List<Comment> selectCommentBySql(int pageNo, int pageSize);

    /**
     * 根据评价编号查询评价信息
     * @param pageNo
     * @param pageSize
     * @return  查询结果
     */
    public List<Comment> getByCommentCid(int pageNo, int pageSize, int cid);

    /**
     * 根据课程编号查询评价信息
     * @param pageNo
     * @param pageSize
     * @param course_id     课程编号
     * @return  查询结果
     */
    public List<Comment> getByCommentCourse(int pageNo, int pageSize, String course_id);

    /**
     *  根据教师编号查询评价信息
     * @param pageNo
     * @param pageSize
     * @param i_id    教师编号
     * @return 结果
     */
    public List<Comment> getByCommentTeacher(int pageNo, int pageSize, String i_id);

    /**
     *  根据班级查询评价信息
     * @param pageNo
     * @param pageSize
     * @param classid      班级编号
     * @return  结果
     */
    public List<Comment> getByCommentClass(int pageNo, int pageSize, String classid);



    /**
     *  ajax验证评价编号是否存在
     * @param cid   评价编号
     * @return  结果
     */
    public String ajaxQueryByCid(String cid);
    List<Comment> findOrder();

}
