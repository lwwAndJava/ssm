package net.fuzui.StudentInfo.pojo;


public class NewStudent {
    public int id;
    public String name;
    public Double score;

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getScore() {
        return this.score;
    }

    @Override
    public String toString() {
        return "NewStudent{ name='" + name + '\'' +
                ", score=" + score +
                '}';
    }
}
