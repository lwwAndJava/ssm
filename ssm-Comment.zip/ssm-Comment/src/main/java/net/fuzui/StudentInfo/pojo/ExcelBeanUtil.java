package net.fuzui.StudentInfo.pojo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 导入excel bean数据工具类
 * @author zhonglinsen
 *
 */
public class ExcelBeanUtil {

    /**
     * 处理产品列表 塞入list-map 等待塞入excel的workbook进行处理
     * @param Comment
     * @return
     */
    public static List<Map<Integer, Object>> manageCommentList(final List<Comment> Comment){
        List<Map<Integer, Object>> dataList=new ArrayList<>();
        if (Comment!=null && Comment.size()>0) {
            int length=Comment.size();

            Map<Integer, Object> dataMap;
            Comment bean;
            for (int i = 0; i < length; i++) {
                bean=Comment.get(i);

                dataMap=new HashMap<>();
                dataMap.put(0, bean.getCommentIid());
                dataMap.put(1, bean.getComment());
                dataMap.put(2, bean.getCommentSid());
                dataMap.put(3, bean.getCid());
                dataMap.put(4, bean.getFrequency());
                dataMap.put(5, bean.getcDate());
                dataMap.put(6,bean.getClassId());
                dataMap.put(7,bean.getCourseId());
                dataMap.put(8,bean.getAnalysisResult());
                dataList.add(dataMap);
            }
        }
        return dataList;
    }
}


