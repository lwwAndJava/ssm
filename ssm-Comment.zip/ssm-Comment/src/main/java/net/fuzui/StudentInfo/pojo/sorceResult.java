package net.fuzui.StudentInfo.pojo;


public class sorceResult {
    public Double value;
    public String name;

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public sorceResult(Double value, String name) {
        this.value = value;
        this.name = name;
    }

    @Override
    public String toString() {
        return "sorceResult{" +
                "value=" + value +
                ", name='" + name + '\'' +
                '}';
    }
}
