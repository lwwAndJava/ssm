package net.fuzui.StudentInfo.mapper;

import net.fuzui.StudentInfo.pojo.Comment;
import net.fuzui.StudentInfo.pojo.analysis;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;


/**
 * @ProjectName: StudentInfo
 * @Package: net.fuzui.StudentInfo.mapper
 * @ClassName: CommentMapper
 * @Description: 评价数据访问层接口类
 */
public interface CommentMapper {



    /**
     *  根据评价编号删除评价信息信息
     * @param cid   评价编号
     * @return  删除结果，!=0则删除成功
     */
    public int deleteComment(String cid);


    /**
     *  根据评价编号查询出评价实体
     * @param cid
     * @return
     */
    public Comment getByConCid(String cid);
    /**
     * 查询全部评价，接住sql语句进行分页
     * @param data
     * @return      查询结果
     */
    public List<Comment> selectCommentBySql(Map<String, Object> data);

    /**
     * 根据评价编号查询评价信息
     * @param data
     * @return  查询结果
     */
    public List<Comment> getByCommentCid(Map<String, Object> data);

    /**
     * 根据课程编号查询评价信息
     * @param data
     * @return  查询结果
     */
    public List<Comment> getByCommentCourse(Map<String, Object> data);

    /**
     *  根据教师编号查询评价信息
     * @param data
     * @return 结果
     */
    public List<Comment> getByCommentTeacher(Map<String, Object> data);

    /**
     *  根据班级编号查询评价信息
     * @param data
     * @return  结果
     */
    public List<Comment> getByCommentClass(Map<String, Object> data);



    /**
     *  ajax验证评价编号是否存在
     * @param cid   评价编号
     * @return  结果
     */
    public String ajaxQueryByCid(String cid);

    List<Comment> findOrder();
    /**
     *  excel导入导出部分
     */

    void insertComment(Map<String, Object> Comment);
    public void insertBatch(@Param("dataList") List<Comment> dataList);
    public  List<Comment> selectAll(@Param("name") String name);
}
