package net.fuzui.StudentInfo.service.impl;

import net.fuzui.StudentInfo.mapper.newStudentInfoDao;
import net.fuzui.StudentInfo.pojo.NewStudent;
import net.fuzui.StudentInfo.service.NewStudentInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class NewStudentInfoServiceImpl implements NewStudentInfoService {
    @Autowired
    private newStudentInfoDao studentInfoDao;
    public List<NewStudent> getAllStudent() {
        return studentInfoDao.getAllStudent();
    }
}
