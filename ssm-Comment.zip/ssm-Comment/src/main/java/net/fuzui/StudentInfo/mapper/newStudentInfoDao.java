package net.fuzui.StudentInfo.mapper;

import net.fuzui.StudentInfo.pojo.NewStudent;

import java.util.List;


public interface newStudentInfoDao {
    List<NewStudent> getAllStudent();
}
