package net.fuzui.StudentInfo.pojo;
/**
* @ProjectName:	StudentInfo
* @Package: net.fuzui.StudentInfo.pojo
* @ClassName: Student
* @Description: 学生实体类
 */

public class Student implements java.io.Serializable{

	//序列化
	private static final long serialVersionUID = 1L;
	//学号
	private String sid;
	//姓名
	private String s_name;
	//性别
	private String ssex;
	//学院名称
	private String dept_name;
	//密码
	private String s_password;
	//邮箱
	private String s_email;
	//班级
	private String class_id;
	//专业
	private String profession;
	
	/**
	 *	默认构造方法
	 * */
	public Student() {
		
	}
	/**
	 * 置取方法
	 * */
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getSname() {
		return s_name;
	}
	public void setSname(String s_name) {
		this.s_name = s_name;
	}
	public String getSsex() {
		return ssex;
	}
	public void setSsex(String ssex) {
		this.ssex = ssex;
	}
	public String getDeptName() {
		return dept_name;
	}
	public void setDeptName(String dept_Name) {
		this.dept_name = dept_Name;
	}
	public String getSpassword() {
		return s_password;
	}
	public void setSpassword(String s_password) {
		this.s_password = s_password;
	}
	public String getsEmail() {
		return s_email;
	}
	public void setsEmail(String s_email) {
		this.s_email = s_email;
	}
	public String getClassr() {
		return class_id;
	}
	public void setClassr(String class_id) {
		this.class_id = class_id;
	}
	public String getProfession() {
		return profession;
	}
	public void setProfession(String profession) {
		this.profession = profession;
	}
	
}
